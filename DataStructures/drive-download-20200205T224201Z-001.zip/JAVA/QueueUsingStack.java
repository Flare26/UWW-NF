

public class QueueUsingStack {
    
    Stack mainStack;
    int maxQueueSize;
    
    public QueueUsingStack(int maxQueueSize) {
        this.maxQueueSize = maxQueueSize;
        mainStack = new Stack(maxQueueSize);
    }
    
    public void enqueue(int val) { // complete this function
    }
    
    public int dequeue() { // complete this function
    }
    
    public int getSize() { // complete this function
    }
    
    public String toString() {
        if (getSize() == 0) {
            return "[]";
        } else {
            String output = "[";
            int n = getSize();
            for (int i = 0; i < n - 1; i++) {
                int x = dequeue();
                output += x + ", ";
                enqueue(x);
            }
            int x = dequeue();
            output += x + "]";
            enqueue(x);
            return output;
        }
    }
}


