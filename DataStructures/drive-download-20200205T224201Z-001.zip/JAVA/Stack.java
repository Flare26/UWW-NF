public class Stack {
    
    private int maxStackSize, topOfStack;
    private int[] stack;
    
    public Stack(int maxStackSize) {
        if (maxStackSize <= 0)
            System.out.println("Stack size should be a positive integer.");
        else {
            this.maxStackSize = maxStackSize;
            topOfStack = -1;
            stack = new int[maxStackSize];
        }
    }
    
    public void push(int val) { // complete this function
    }
    
    public int pop() { // complete this function
    }
    
    public int getSize() { // complete this function
    }
}


