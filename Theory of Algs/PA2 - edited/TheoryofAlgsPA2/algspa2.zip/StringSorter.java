

public class StringSorter {
	
	public static void radixSort(String[] strings, int n) { // complete this method
	}

	private static void countSortOnLowerCaseCharacters(String[] strings, int n, int[] digits) { // complete this method
	}
}
