using System;
namespace _433_PA1
{
    public class Selection : Partition
    {
        public Selection(int[] array, int n) : base(array, n)
        {
        }

        public int select(int k)
        {
            return select(0, n - 1, k);
        }

        private int select(int left, int right, int k)
        { // complete this function
            if (left == right)
                return array[left];

                int ptx = left - 1;
                int piv = generateRandomPivot(left, right);
                ptx = partition(left, right, piv);

                if (k == ptx - left + 1)
                    return piv;

                else if (k < ptx - left + 1)
                    return select(left, ptx - 1, k);
                else
                    return select(ptx+1, right, k - ( ptx - left + 1));
            
        }
    }
}
