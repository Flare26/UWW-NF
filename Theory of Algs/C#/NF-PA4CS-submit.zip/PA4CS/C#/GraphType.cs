﻿using System;
namespace _PA4
{
    public enum GraphType
    {
        WEIGHTED,
        UNWEIGHTED
    }
}
