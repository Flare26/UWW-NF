﻿using System;
using System.Collections.Generic;

namespace _PA4
{
	public class Johnson : Graph
	{

		public Johnson(Graph graph) : base(graph) { }

        public int[][] execute()
        { // complete this method
            adjList.Add(new List<Edge>());

            for (int i = 0; i < numVertices; i++)
            {
                Edge e = new Edge(numVertices, i, 0); // numVertices just guarantees a new dummy vertex not already in the list
                adjList[numVertices].Add(e);
            }
            numEdges += numVertices;
            numVertices++;

            BellmanFord bf = new BellmanFord(this); // polymorphism since this Johnson is also a Graph
            int[] phis = bf.execute(numVertices - 1); // above we just updated the numVertices to account for the new vertex so - 1 to account for that index

            //remove dummies, not needed for 'this' parameter pass any more
            numVertices--;
            numEdges -= numVertices;
            adjList.RemoveAt(numVertices); // remove entire row

            if (phis == null || phis.Length == 0)
                return null;

            // Modify edge weights using the phi array
            for (int v = 0; v < adjList.Count; v++)
            {
                for (int e = 0; e < adjList[v].Count; e++)
                {
                    Edge edge = adjList[v][e];
                    edge.weight = edge.weight + phis[edge.src] - phis[edge.dest];
                }
            }

            int[][] allPairMatrix = new int[numVertices][];
            Dijkstra dijkstra = new Dijkstra(this);

            for (int i = 0; i < numVertices; i++)
            {
                allPairMatrix[i] = dijkstra.execute(i);
            }

            return allPairMatrix;
        }

    }
}
