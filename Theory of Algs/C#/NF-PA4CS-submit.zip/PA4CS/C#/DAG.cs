using System;
using System.Collections.Generic;
using System.Numerics;

namespace _PA4
{
    public class DAG : Graph
    {

        public DAG(Graph graph) : base(graph)
        {
        }

        public List<int> topoSort()
        {
            List<int> topoOrder = new List<int>();
            int[] inDegree = new int[numVertices];
            for (int i = 0; i < numVertices; i++)
                inDegree[i] = 0;

            for (int i = 0; i < numVertices; i++)
                foreach (Edge e in adjList[i])
                    inDegree[e.dest]++;

            Queue<int> q = new Queue<int>();
            for (int i = 0; i < numVertices; i++)
                if (inDegree[i] == 0)
                    q.Enqueue(i);

            while (q.Count > 0)
            {
                int u = q.Dequeue();
                topoOrder.Add(u);
                foreach (Edge e in adjList[u])
                {
                    inDegree[e.dest]--;
                    if (inDegree[e.dest] == 0)
                        q.Enqueue(e.dest);
                }
            }
            if (topoOrder.Count != numVertices)
                return null;
            return topoOrder;
        }

        public int[] longestPaths(int s)
        { // complete this method
            //Topologically sort vertices
            List<int> topo = topoSort();

            int[] dist = new int [numVertices];

            for (int i = 0; i < numVertices; i++)
                dist[i] = Int32.MinValue;

            dist[s] = 0;

            for (int v = 0; v < topo.Count; v++)
            {
                List<Edge> outEdges = adjList[topo[v]];
                for (int adjEdge = 0; adjEdge < outEdges.Count; adjEdge++)
                {
                    int adjVertex = outEdges[adjEdge].dest;
                    if (dist[v] != Int32.MinValue)
                    {
                        int len = dist[v] + outEdges[adjEdge].weight;
                        if (len > dist[adjVertex])
                            dist[adjVertex] = len;
                    }
                }
            }
            return dist;
        }

        public int[][] countOddEvenHops(int s)
        {
            // Topologically sort the vertices
            List<int> topo = topoSort();

            // Initialize memoization tables for even and odd counts
            int[][] memoEven = new int[numVertices][];
            int[][] memoOdd = new int[numVertices][];
            for (int i = 0; i < numVertices; i++)
            {
                memoEven[i] = new int[2];
                memoOdd[i] = new int[2];
            }

            // Calculate even and odd counts using separate recursive functions
            countEven(s, topo, memoEven);
            countOdd(s, topo, memoOdd);

            // Prepare the result array with the first row for even counts and the second row for odd counts
            int[][] result = new int[2][];
            result[0] = new int[numVertices];
            result[1] = new int[numVertices];

            // Fill the result array with even and odd counts from the memoization tables
            for (int i = 0; i < numVertices; i++)
            {
                result[0][i] = memoEven[i][0];
                result[1][i] = memoOdd[i][0];
            }

            return result;
        }

        // countEven calculates the even count from the source vertex to each vertex using memoization
        private void countEven(int vertex, List<int> topo, int[][] memo)
        {
            if (memo[vertex][0] != 0) // If memo table has value, return
                return;

            memo[vertex][0] = 1; // Mark as visited

            // Iterate through outgoing edges of the current vertex
            List<Edge> outEdges = adjList[vertex];

            foreach (Edge edge in outEdges)
            {
                int adjVertex = edge.dest;

                // Call the countOdd function for adjacent vertex
                countOdd(adjVertex, topo, memo);

                // Update the even count for the adjacent vertex
                memo[adjVertex][0] += memo[vertex][1];
            }
        }

        // countOdd calculates the odd count from the source vertex to each vertex using memoization
        private void countOdd(int vertex, List<int> topo, int[][] memo)
        {
            if (memo[vertex][1] != 0) // If memo table has value, return
                return;

            memo[vertex][1] = 1; // Mark as visited

            // Iterate through outgoing edges of the current vertex
            List<Edge> outEdges = adjList[vertex];

            foreach (Edge edge in outEdges)
            {
                int adjVertex = edge.dest;

                // Call the countEven function for adjacent vertex
                countEven(adjVertex, topo, memo);

                // Update the odd count for the adjacent vertex
                memo[adjVertex][1] += memo[vertex][0];
            }
        }

    }
}
