#include <iostream>
#include <vector>
#include <set>
#include <climits>
using namespace std;

#ifndef SUBSETSUM_H_
#define SUBSETSUM_H_

class SubsetSum {

public:

    static bool isSumPossible(const int elements[], int numElements,
            int target) {
        set<int> sums;
        sums.insert(0);
        for (int i = 0; i < numElements; i++) {
            int *temp = new int[sums.size()];
            int j = 0;
            set<int>::iterator it = sums.begin();
            while (it != sums.end()) {
                temp[j++] = *it;
                it++;
            }
            int s = sums.size();
            for (j = 0; j < s; j++) {
                int val = temp[j] + elements[i];
                if (val == target)
                    return true;
                else if (val < target)
                    sums.insert(val);
            }
            delete[] temp;
        }
        return false;
    }
};

#endif /* SUBSETSUM_H_ */
