#include <string>
#include <vector>
#include <stdio.h>
using namespace std;

#ifndef VankinsMile_h
#define VankinsMile_h

class VankinsMile {

public:
    
    static void findBestPath(int **board, int numRows, int numCols, int startRow, int startCol) {
        // complete this function
    }
    
private:

    static void pathFinder(int **values, char **directions, int numRows, int numCols, int startRow, int startCol) {
        printBoard(values, directions, numRows, numCols);
        int max = INT_MIN;
        int maxR = 0;
        int maxC = 0;
        vector<int*> path;
        for (int i = startRow; i < numRows; i++)
            if (values[i][numCols - 1] > max) {
                max = values[i][numCols - 1];
                maxR = i;
                maxC = numCols - 1;
            }
        for (int j = startCol; j < numCols; j++)
            if (values[numRows - 1][j] > max) {
                max = values[numRows - 1][j];
                maxR = numRows - 1;
                maxC = j;
            }
        cout << "\nMaximum gain is: " << max << endl;
        while (maxR >= startRow && maxC >= startCol) {
            int *node = new int[2];
            node[0] = maxR;
            node[1] = maxC;
            path.push_back(node);
            if (directions[maxR][maxC] == 'L')
                maxC--;
            else
                maxR--;
        }
        reverse(path);
        
        cout << "Path: ";
        if (path.size() == 0)
            return;
        int *node;
        for (int i = 0; i < path.size() - 1; i++) {
            node = path.at(i);
            printf("[%d,%d] --> ", node[0], node[1]);
            delete[] node;
        }
        node = path.at(path.size() - 1);
        printf("[%d,%d]\n", node[0], node[1]);
        delete[] node;
    }

    static void printBoard(int **values, char **directions, int numRows, int numCols) {
        cout << "\nSolution (Value/Direction) Board" << endl;
        if (numRows == 0 || numCols == 0) {
            cout << "[]" << endl;
            return;
        }
        for (int i = 0; i< numRows; i++) {
            string val = values[i][0] == INT_MIN ? "-inf" : to_string(values[i][0]);
            string out = "[" + val + "/" + directions[i][0];
            for (int j = 1; j < numCols; j++) {
                val = values[i][j] == INT_MIN ? "-inf" : to_string(values[i][j]);
                out += ", " + val + "/" + directions[i][j];
            }
            out += "]";
            cout << out << endl;
        }
    }
    
    static void reverse(vector<int *> &list) {
        for (int i = 0, j = list.size() - 1; i < j; i++, j--) {
            int *temp = list.at(j);
            list[j] = list.at(i);
            list[i] = temp;
        }
    }
};

#endif /* VankinsMile_h */
