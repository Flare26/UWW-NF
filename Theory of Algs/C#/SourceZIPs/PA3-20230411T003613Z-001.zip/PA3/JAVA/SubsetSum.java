import java.util.Iterator;
import java.util.TreeSet;

public class SubsetSum {

	public static boolean isSumPossible(final int elements[], int numElements, int target) {
		TreeSet<Integer> sums = new TreeSet<Integer>();
		sums.add(0);
		for (int i = 0; i < numElements; i++) {
			int[] temp = new int[sums.size()];
			Iterator<Integer> it = sums.iterator();
			int j = 0;
			while (it.hasNext()) {
				int val = it.next() + elements[i];
				if (val == target)
					return true;
				temp[j++] = val;
			}
			for (int val : temp)
				sums.add(val);
		}
		return false;
	}
}