using System;
namespace _PA3
{
    public class BinaryStrings
    {
		public static int numberOfBinaryStringsWithNoConsecutiveOnes(int n)
		{ // complete this method
		}
	}
}
