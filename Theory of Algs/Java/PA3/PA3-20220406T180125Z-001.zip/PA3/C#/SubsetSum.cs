using System;
using System.Collections.Generic;
namespace _PA3
{
    public class SubsetSum
    {
		public static bool isSumPossible(int[] elements, int numElements, int target)
		{   // complete this function
		}
	}
}
