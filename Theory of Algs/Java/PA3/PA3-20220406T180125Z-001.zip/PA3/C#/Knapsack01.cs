using System;
namespace _PA3
{
	public class Knapsack01
	{
		public static int findOptimalProfit(int[] profits, int[] weights, int numElements, int capacity)
		{ // complete this function
		}
	}
}
