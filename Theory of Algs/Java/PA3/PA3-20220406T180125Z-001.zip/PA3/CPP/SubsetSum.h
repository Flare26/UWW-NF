#include <iostream>
#include <vector>
#include <set>
#include <climits>
using namespace std;

#ifndef SUBSETSUM_H_
#define SUBSETSUM_H_

class SubsetSum {

public:

	static bool isSumPossible(const int elements[], int numElements,
			int target) { // complete this function
	}
};

#endif /* SUBSETSUM_H_ */
