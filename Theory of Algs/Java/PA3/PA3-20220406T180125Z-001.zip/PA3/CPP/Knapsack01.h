#include <iostream>
#include <algorithm>
using namespace std;

#ifndef KNAPSACK01_H_
#define KNAPSACK01_H_

class Knapsack01 {

public:

	static int findOptimalProfit(const int profits[], const int weights[], int numElements,
			int capacity) { // complete this function
	}
};

#endif /* KNAPSACK01_H_ */
