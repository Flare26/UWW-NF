#ifndef BINARYSTRINGS_H_
#define BINARYSTRINGS_H_

class BinaryStrings {

public:

	static int numberOfBinaryStringsWithNoConsecutiveOnes(int n) { // complete this method
	}
};

#endif /* BINARYSTRINGS_H_ */
