public class BinaryStrings {

	public static int numberOfBinaryStringsWithNoConsecutiveOnes(int n) { // complete this method
	}
}
