public class Knapsack01 {
	
	public static int findOptimalProfit(final int profits[], final int weights[], int numElements, int capacity) { // complete this function
	}
}
