import java.util.Iterator;
import java.util.TreeSet;

public class SubsetSum {

	public static boolean isSumPossible(final int elements[], int numElements, int target) { // complete this function
	}
}
