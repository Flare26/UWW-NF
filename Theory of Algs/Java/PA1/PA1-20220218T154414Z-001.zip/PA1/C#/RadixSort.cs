using System;
namespace _433_PA1
{
    public class RadixSort
    {
        private readonly int[] array;
        private readonly int n;

        public RadixSort(int[] array, int length)
        {
            this.array = array;
            this.n = length;
        }

        private static void countSortOnDigits(int[] A, int n, int[] digits)
        { // complete this function
        }

        private static void radixSortNonNeg(int[] A, int n)
        { // complete this function
        }

        public void radixSort()
        { // complete this function
        }
    }
}
