using System;
namespace _433_PA1
{
    public class QuickSort : Partition
    {
        public QuickSort(int[] array, int n) : base(array, n)
        {
        }

        public void quicksortMedianOf3()
        {
            quicksortMedianOf3(0, n - 1);
        }

        public void quicksortRandom()
        {
            quicksortRandom(0, n - 1);
        }

        private void quicksortMedianOf3(int left, int right)
        { // complete this function
        }

        private void quicksortRandom(int left, int right)
        { // complete this function
        }
    }
}
